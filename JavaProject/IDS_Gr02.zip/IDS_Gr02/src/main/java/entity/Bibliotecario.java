package entity;

import database.GestorePersistenza;
import jakarta.persistence.*;

import javax.swing.*;
import java.time.LocalTime;
import java.util.List;

@Entity
public class Bibliotecario{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long codiceInterno;

    private String nome;
    private String cognome;
    private String email;
    private String password;

    @OneToMany
    private static List<SalaStudio> saleStudio;

    public Bibliotecario(){

    }
    public static final GestorePersistenza gp = new GestorePersistenza();

    public static boolean creaSalaStudio(String nome,
                                     String descrizione,
                                     int numeroPostazioniTotali,
                                     LocalTime orarioApertura,
                                     LocalTime orarioChiusura,
                                     boolean presenzaAree){

        if(orarioApertura.isBefore(orarioChiusura)){
            SalaStudio s = new SalaStudio(nome, descrizione, numeroPostazioniTotali, orarioApertura, orarioChiusura, presenzaAree);
            if(presenzaAree){
                //s.aggiungiArea();
            }
            gp.salva(s);
            saleStudio.add(s);
            return true;
        }
        JOptionPane.showMessageDialog(null, "L'orario di apertura non può essere successivo a quello di chiusura");
        return false;

    }
}