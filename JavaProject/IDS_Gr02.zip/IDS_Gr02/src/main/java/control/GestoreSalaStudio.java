package control;

import entity.*;

import javax.swing.*;
import java.time.LocalTime;

public class GestoreSalaStudio {

    public GestoreSalaStudio(){

    }

    public static boolean aggiungiSalaStudio(String nome,
                                             String descrizione,
                                             int numeroPostazioniTotali,
                                             LocalTime orarioApertura,
                                             LocalTime orarioChiusura,
                                             boolean presenzaAree){
        return Bibliotecario.creaSalaStudio(nome, descrizione, numeroPostazioniTotali, orarioApertura, orarioChiusura, presenzaAree);
    }
}
