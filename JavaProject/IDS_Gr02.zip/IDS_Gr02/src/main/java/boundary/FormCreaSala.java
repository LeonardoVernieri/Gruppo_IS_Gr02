package boundary;
import control.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;

public class FormCreaSala extends JFrame{
    private JLabel lblTitoloCrea;
    private JTextField nomeSala;
    private JTextField numPostazioniTotali;
    private JTextField descrizione;
    private JLabel lblNome;
    private JLabel lblNumPostazioni;
    private JLabel lblDescrizione;
    private JButton btnSalva;
    private JPanel contentPane;
    private JButton btnAnnulla;
    private JComboBox comboApertura;
    private JComboBox comboChiusura;
    private JLabel lblOrarioA;
    private JLabel lblOrarioC;
    private JLabel areePresenza;
    private JCheckBox ckbPresenza;
    private JLabel lblAggiungiArea;
    private JLabel lblTipologia;
    private JLabel lblPostazioniArea;
    private JPanel panelAggiungiArea;
    private JButton btnAdd;
    private JSpinner spinner1;
    private JComboBox comboBox1;
    private JTable tabellaAree;
    private JTextField numAree;

    private FormBibliotecario parent;

    public void StampaDati(){
        String nome = nomeSala.getText();
        String descrizione = this.descrizione.getText();
        int numeroPostazioniTotali = Integer.parseInt(numPostazioniTotali.getText());
        LocalTime orarioApertura = LocalTime.parse((String) comboApertura.getSelectedItem());
        LocalTime orarioChiusura = LocalTime.parse((String)comboChiusura.getSelectedItem());
        boolean presenzaAree = ckbPresenza.isSelected();

        boolean esito = GestoreSalaStudio.aggiungiSalaStudio(nome, descrizione, numeroPostazioniTotali, orarioApertura, orarioChiusura, presenzaAree);

        if(esito){
            btnSalva.setForeground(Color.GREEN);
        }
        else{
            btnSalva.setForeground(Color.RED);
        }
    }

    public FormCreaSala(FormBibliotecario parent) {
        this.parent = parent;

        setTitle("Crea Sala");
        setContentPane(contentPane);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        numAree.setEnabled(false);

        btnSalva.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StampaDati();
            }
        });

        btnAnnulla.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parent.setVisible(true);
                dispose();
            }
        });
        ckbPresenza.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(ckbPresenza.isSelected()){
                    numAree.setEnabled(true);
                }
                else{
                    numAree.setEnabled(false);
                }
            }
        });
    }
}
